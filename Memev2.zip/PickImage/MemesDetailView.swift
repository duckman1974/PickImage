//
//  MemesDetailView.swift
//  PickImage
//
//  Created by Candice Reese on 2/12/17.
//  Copyright © 2017 Kevin Reese. All rights reserved.
//

import Foundation
import UIKit

class MemesDetailView: UIViewController {
    
    
    var meme: Meme!
    
    
    @IBOutlet weak var memeImage: UIImageView!
    
    

    
    

    
    
    
    
}
