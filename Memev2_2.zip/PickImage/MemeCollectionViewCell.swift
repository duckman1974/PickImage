//
//  MemeCollectionViewCell.swift
//  PickImage
//
//  Created by Candice Reese on 2/10/17.
//  Copyright © 2017 Kevin Reese. All rights reserved.
//

import UIKit


class MemeCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var memeImg: UIImageView!
    
    
}
