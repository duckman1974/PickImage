//
//  HelperFile.swift
//  PickImage
//
//  Created by Kevin Reese on 1/22/17.
//  Copyright © 2017 Kevin Reese. All rights reserved.
//


import UIKit

struct Meme
{
    let topText: String!
    let bottomText: String!
    let originalImage: UIImage!
    let memedImage: UIImage!
    
   
}
